class SimulationNest extends Simulation {

  val httpProtocol8080 = http
    .baseUrl("http://0.0.0.0:9999")

  val scn8080 = scenario("Login on Nginx PHP7 + Auth Server in Node")
    .exec(
      http("Nginx_Auth Server+PHP7")
      .get("/api/me_authserver")
      .header("content-type", "application/json")
      // .body(RawFileBody("php7-payload.json"))
      .check(status.is(200))
    )

  setUp(
    scn8080.inject(
      // constantUsersPerSec(5).during(15.seconds).randomized,
      rampUsersPerSec(10).to(100).during(30.seconds),
      constantUsersPerSec(100).during(30.seconds),
    )
  ).protocols(httpProtocol8080)
}
